-- ============================================================
-- 1. DỌN DẸP DATABASE CŨ (DROP TABLES)
-- ============================================================
DROP TABLE IF EXISTS "payment", "ship", "orderdetail", "Order", "cartdetail", "cart", "admin", "product", "category", "User" CASCADE;

-- ============================================================
-- 2. TẠO CẤU TRÚC BẢNG (SCHEMA)
-- ============================================================

-- Bảng Category
CREATE TABLE category (
    categoryID serial primary key,
    categoryName varchar(100) not null
);

-- Bảng Product
CREATE TABLE product (
    productID serial primary key,
    categoryID int references category(categoryID) on delete set null,
    productName varchar(100) not null,
    description text,
    price bigint,
    product_code varchar(50),
    number_of_sale int default 0,
    images text,
    stock_quantity int not null default 0,
    check(stock_quantity >= 0)
);

-- Bảng User
CREATE TABLE "User" (
    userID SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phonenumber VARCHAR(15),
    address TEXT,
    age INT,
    cccd varchar(13),
    user_role VARCHAR(10) NOT NULL DEFAULT 'Member' CHECK (user_role IN ('Member', 'Admin')),
    otp_code VARCHAR(10),
    otp_expires_at TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Bảng Admin
CREATE TABLE admin (
    adminID int primary key references "User"(userID) on delete cascade,
    adminLevel int default 1
);

-- Bảng Cart & CartDetail
CREATE TABLE Cart (
    cartID SERIAL PRIMARY KEY,
    userID INT UNIQUE NOT NULL REFERENCES "User"(userID) ON DELETE CASCADE
);

CREATE TABLE CartDetail (
    cartDetailID SERIAL PRIMARY KEY,
    cartID INT NOT NULL REFERENCES Cart(cartID) ON DELETE CASCADE,
    productID INT NOT NULL REFERENCES product(productID) ON DELETE CASCADE,
    quantity INT NOT NULL CHECK (quantity > 0),
    unitPrice bigint NOT NULL 
);

-- Bảng Order & OrderDetail
CREATE TABLE "Order" (
    orderID SERIAL PRIMARY KEY,
    userID INT REFERENCES "User"(userID) ON DELETE SET NULL, 
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    totalAmount BIGINT NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'New Order'
);

CREATE TABLE OrderDetail (
    orderDetailID SERIAL PRIMARY KEY,
    orderID INT NOT NULL REFERENCES "Order"(orderID) ON DELETE CASCADE,
    productID INT REFERENCES product(productID) ON DELETE SET NULL, 
    quantity INT NOT NULL CHECK (quantity > 0),
    unitPrice BIGINT NOT NULL 
);

-- Bảng Ship
CREATE TABLE Ship (
    shipID SERIAL PRIMARY KEY,
    orderID INT UNIQUE NOT NULL REFERENCES "Order"(orderID) ON DELETE CASCADE,
    shipAddress TEXT NOT NULL, 
    recipient_name VARCHAR(100) NOT NULL, 
    recipient_phone VARCHAR(20) NOT NULL, 
    shipDate TIMESTAMP,
    shipFee BIGINT NOT NULL DEFAULT 0
);

-- Bảng Payment
CREATE TABLE Payment (
    paymentID SERIAL PRIMARY KEY,
    orderID INT NOT NULL REFERENCES "Order"(orderID),
    paymentMethod VARCHAR(30) NOT NULL, 
    amount BIGINT NOT NULL,
    paymentDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(30) DEFAULT 'Pending'
);

-- ============================================================
-- 3. DATA SEEDING (NHẬP DỮ LIỆU MẪU)
-- ============================================================

-- A. Thêm Danh mục
INSERT INTO category(categoryName) VALUES 
('Điện thoại'),          -- ID: 1
('Laptop'),              -- ID: 2
('Phụ kiện'),            -- ID: 3
('Máy tính bảng'),       -- ID: 4
('Đồng hồ thông minh'),  -- ID: 5
('PC & Màn hình'),       -- ID: 6
('Thiết bị âm thanh');   -- ID: 7

-- B. Thêm Sản phẩm (Đã gộp tất cả vào một lệnh INSERT lớn để tránh lỗi)
INSERT INTO product(productName, categoryID, product_code, description, price, stock_quantity, images) VALUES 
-- 1. ĐIỆN THOẠI (Cũ + Mới)
('iPhone 15 Pro Max', 1, 'IP15', 'Titanium, 256GB', 34000000, 50, 'iphone.png'),
('Samsung Galaxy S24 Ultra', 1, 'SS-S24U', 'Chip Snapdragon 8 Gen 3, Camera 200MP, Bút S-Pen tích hợp AI.', 31990000, 50, 's24ultra.jpg'),
('Xiaomi 14 Ultra', 1, 'MI-14U', 'Ống kính Leica thế hệ mới, cảm biến 1 inch, sạc nhanh 90W.', 24990000, 30, 'xiaomi14.jpg'),
('Google Pixel 8 Pro', 1, 'PIXEL8', 'Camera AI chụp đêm siêu đỉnh, Android gốc mượt mà.', 18500000, 20, 'pixel8.jpg'),
('Samsung Galaxy Z Fold6', 1, 'Z-FOLD6', 'Điện thoại gập mỏng nhất, Galaxy AI, thiết kế vuông vức sang trọng.', 43990000, 20, 'zfold6.jpg'),
('OPPO Find N3', 1, 'OPPO-N3', 'Camera Hasselblad chuyên nghiệp, nếp gấp tàng hình.', 41990000, 15, 'oppo_n3.jpg'),
('iPhone 15', 1, 'IP15-STD', 'Dynamic Island, Camera 48MP, cổng USB-C tiện lợi.', 19500000, 100, 'ip15_std.jpg'),
('Asus ROG Phone 8 Pro', 1, 'ROG-P8', 'Gaming Phone tối thượng, AniMe Vision, Snapdragon 8 Gen 3.', 29000000, 10, 'rog_phone8.jpg'),

-- 2. LAPTOP (Cũ + Mới)
('MacBook Air M2', 2, 'MACM2', 'Apple M2 Chip', 26000000, 20, 'macbook.png'),
('Asus ROG Zephyrus G14', 2, 'ROG-G14', 'Laptop Gaming 14 inch mạnh nhất thế giới, màn hình OLED 120Hz.', 42000000, 15, 'rog_g14.jpg'),
('Dell XPS 13 Plus', 2, 'XPS-13P', 'Thiết kế tương lai, bàn phím vô hình, màn hình 4K cảm ứng.', 38900000, 10, 'dell_xps.jpg'),
('Lenovo ThinkPad X1 Carbon', 2, 'TP-X1', 'Ông vua văn phòng, siêu nhẹ, bàn phím gõ sướng nhất.', 32500000, 25, 'thinkpad.jpg'),
('MacBook Pro 16 M3 Max', 2, 'MAC-M3MAX', 'Hiệu năng khủng khiếp cho Designer/Coder, RAM 36GB.', 80000000, 5, 'mac_m3max.jpg'),
('Acer Nitro 5 Tiger', 2, 'ACER-NITRO', 'Laptop Gaming quốc dân, tản nhiệt cực mát, giá sinh viên.', 17990000, 50, 'nitro5.jpg'),
('LG Gram 2024', 2, 'LG-GRAM', 'Siêu nhẹ chỉ 999g, độ bền chuẩn quân đội, pin 20 tiếng.', 35000000, 12, 'lg_gram.jpg'),
('MSI Raider GE78', 2, 'MSI-GE78', 'Led RGB ma trận, cấu hình thách thức mọi tựa game AAA.', 65000000, 8, 'msi_raider.jpg'),

-- 3. PHỤ KIỆN (Cũ + Mới)
('Sony WH-1000XM5', 3, 'SONY-HP', 'Tai nghe chống ồn chủ động tốt nhất thị trường.', 6990000, 40, 'sony_xm5.jpg'),
('Chuột Logitech MX Master 3S', 3, 'MX-3S', 'Chuột văn phòng yên tĩnh, cuộn vô cực, kết nối 3 thiết bị.', 2100000, 100, 'mx_master3.jpg'),
('Bàn phím cơ Keychron Q1 Pro', 3, 'KEY-Q1', 'Bàn phím cơ Custom, khung nhôm nguyên khối, kết nối Bluetooth.', 4500000, 30, 'keychron.jpg'),
('Sạc dự phòng Anker 737', 3, 'ANKER-737', 'Công suất 140W, sạc được cho cả Laptop, màn hình hiển thị thông số.', 2800000, 60, 'anker737.jpg'),
('Webcam Logitech C920', 3, 'LOGI-C920', 'Full HD 1080p, quay nét, mic lọc tạp âm, chuyên Stream.', 1800000, 45, 'c920.jpg'),
('Tay cầm PS5 DualSense', 3, 'PS5-CTRL', 'Rung phản hồi xúc giác, trigger thích ứng, thiết kế ergonomic.', 1690000, 60, 'ps5_controller.jpg'),
('Ổ cứng SSD Samsung T7 1TB', 3, 'SSD-T7', 'Ổ cứng di động siêu tốc, bảo mật vân tay, nhỏ gọn.', 3200000, 35, 'ssd_t7.jpg'),
('Hub chuyển đổi Baseus 8-in-1', 3, 'BASEUS-HUB', 'Mở rộng cổng kết nối cho MacBook: HDMI, LAN, USB 3.0.', 850000, 120, 'baseus_hub.jpg'),

-- 4. MÁY TÍNH BẢNG (Mới)
('iPad Pro M4 13 inch', 4, 'IPAD-M4', 'Chip M4 mạnh nhất lịch sử, màn hình OLED Tandem siêu thực.', 38000000, 25, 'ipad_m4.jpg'),
('Samsung Galaxy Tab S9 Ultra', 4, 'TAB-S9U', 'Màn hình khổng lồ 14.6 inch, chống nước IP68, kèm bút S-Pen.', 29000000, 18, 'tab_s9u.jpg'),
('Xiaomi Pad 6', 4, 'MI-PAD6', 'Màn hình 144Hz mượt mà, Snapdragon 870, giá rẻ hiệu năng cao.', 8900000, 40, 'mipad6.jpg'),

-- 5. ĐỒNG HỒ THÔNG MINH (Mới)
('Apple Watch Ultra 2', 5, 'AW-ULTRA2', 'Vỏ Titanium, màn hình 3000 nits, chuyên lặn biển và thám hiểm.', 21500000, 15, 'aw_ultra2.jpg'),
('Garmin Fenix 7 Pro', 5, 'GAR-F7', 'Pin năng lượng mặt trời, bản đồ Offline, vua thể thao.', 23900000, 10, 'garmin_f7.jpg'),
('Samsung Galaxy Watch 6 Classic', 5, 'SS-W6C', 'Vòng bezel xoay vật lý huyền thoại, theo dõi sức khỏe toàn diện.', 7500000, 30, 'watch6_classic.jpg'),

-- 6. PC & MÀN HÌNH (Mới)
('VGA Asus ROG Strix RTX 4090', 6, 'RTX-4090', 'Card đồ họa mạnh nhất thế giới, 24GB VRAM, chiến game 8K.', 62000000, 3, 'rtx4090.jpg'),
('CPU Intel Core i9-14900K', 6, 'I9-14900K', '24 nhân 32 luồng, xung nhịp 6.0GHz, trùm xử lý đa nhiệm.', 15900000, 20, 'i9_14900k.jpg'),
('Màn hình LG UltraGear OLED', 6, 'LG-27GR', 'Tấm nền OLED 240Hz, phản hồi 0.03ms, màu đen tuyệt đối.', 19900000, 8, 'lg_oled.jpg'),
('Màn hình Samsung Odyssey G9', 6, 'SS-G9', 'Màn hình cong 49 inch tỷ lệ 32:9, bao quát tầm nhìn.', 25000000, 5, 'odyssey_g9.jpg'),

-- 7. THIẾT BỊ ÂM THANH (Mới)
('Loa Marshall Stanmore III', 7, 'MAR-STAN3', 'Thiết kế cổ điển, âm thanh Rock mạnh mẽ, kết nối Bluetooth 5.2.', 9500000, 20, 'marshall.jpg'),
('Tai nghe Airpods Pro 2', 7, 'AIR-PRO2', 'Chống ồn chủ động gấp 2 lần, cổng sạc USB-C, pin trâu.', 5900000, 80, 'airpod_pro2.jpg'),
('Loa JBL PartyBox 310', 7, 'JBL-PB310', 'Công suất 240W, đèn LED RGB theo nhạc, quẩy tiệc xuyên đêm.', 14500000, 10, 'jbl_party.jpg');

-- C. Thêm Tài khoản Admin
INSERT INTO "User" (username, password, email, phonenumber, address, age, cccd, user_role, is_active)
VALUES (
    'Super Admin', 
    '$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWrn96pzbPnOJ8bTxlK.n/8jLcG6.q', 
    'admin@gmail.com', 
    '0909123456', 
    'System HQ', 
    30, 
    '001090123456', 
    'Admin',
    TRUE
);