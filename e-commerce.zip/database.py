import psycopg2
import os
import time  # <--- Thư viện giúp tạm dừng để chờ

def db_connection():
    # 1. Xác định Host và Port dựa trên môi trường
    # Nếu chạy trong Docker, host là "postgres". Nếu chạy ngoài, host là "localhost"
    db_host = os.environ.get("DB_HOST", "localhost")
    
    if db_host == "postgres":
        db_port = "5432" # Cổng nội bộ Docker
    else:
        db_port = "5433" # Cổng máy ngoài (nếu bạn chạy test ko qua docker)

    # 2. Vòng lặp thử kết nối (Retry Mechanism)
    max_retries = 10  # Thử tối đa 10 lần
    for i in range(max_retries):
        try:
            print(f"🔌 [Lần {i+1}/{max_retries}] Đang thử kết nối đến {db_host}:{db_port}...")
            
            conn = psycopg2.connect(
                database = "mydb",
                user = "group14",
                password = "1234",
                host = db_host,
                port = db_port
            )
            print(f"✅ KẾT NỐI THÀNH CÔNG!")
            return conn
            
        except Exception as e:
            print(f"⚠️ Chưa kết nối được (Database đang khởi động?). Đợi 3 giây...")
            time.sleep(3) # Ngủ 3 giây rồi thử lại

    # Nếu thử 10 lần (30 giây) mà vẫn không được thì mới chịu thua
    print("❌ TỪ CHỐI KẾT NỐI: Vui lòng kiểm tra lại Docker Database.")
    return None