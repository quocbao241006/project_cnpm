import os
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from PIL import Image 

console = Console()

def clear(): 
    os.system('cls' if os.name == 'nt' else 'clear')


# 1. HÀM HIỂN THỊ ẢNH

def show_image(image_name, width=60, max_height=30):
    """Hàm hiển thị ảnh an toàn cho Docker"""
    if not image_name: return

    # Kiểm tra xem có đang chạy trong Docker không
    if os.environ.get("DB_HOST") == "postgres":
        console.print(f"[yellow]>> [DOCKER MODE] Đã tìm thấy ảnh '{image_name}' (Không thể mở popup trong Docker)[/yellow]")
        return

    # Code cũ giữ nguyên (để chạy trên máy thật vẫn mở được)
    image_path = os.path.join("images", image_name)
    if not os.path.exists(image_path):
        console.print(f"[dim italic](Không tìm thấy file ảnh: {image_name})[/dim italic]")
        return

    try:
        img = Image.open(image_path)
        img.show()
        console.print(f"[bold green]>> Đang mở ảnh: {image_name}[/bold green]")
    except Exception as e:
        console.print(f"[red]Lỗi hiển thị ảnh: {e}[/red]")
# 2. HÀM XEM CHI TIẾT & MUA

def view_product_detail(current_user, product, cart_repo):
    clear()
    # 1. Hiển thị thông tin text
    console.print(f"[bold green]{product['productName'].upper()}[/bold green]", justify="center")
    console.print(f"Giá: [bold red]{float(product['price']):,.0f} đ[/bold red]", justify="center")
    console.print(f"Tồn kho: {product['stock_quantity']}")
    console.print(Panel(product['description'], title="Mô tả"))
    
    # 2. Mở ảnh Popup
    show_image(product['images']) 
    
    # 3. Menu mua hàng
    console.print("\n[bold yellow]1. Thêm vào giỏ hàng (UC-6)[/bold yellow]")
    console.print("0. Quay lại")
    
    choice = input("Chọn: ").strip()
    
    if choice == '1':
        if not current_user:
            console.print("[red]Vui lòng Đăng nhập để mua hàng![/red]")
            console.input("Enter...")
            return

        try:
            qty_input = input("Nhập số lượng mua: ")
            if not qty_input.isdigit():
                console.print("[red]Vui lòng nhập số![/red]")
                console.input("Enter...")
                return
                
            qty = int(qty_input)
            if qty > 0:
                if qty > product['stock_quantity']:
                     console.print("[red]Số lượng tồn kho không đủ![/red]")
                else:
                    # Thêm vào giỏ
                    cart_repo.add_to_cart(
                        current_user['userID'], 
                        product['productID'], 
                        qty, 
                        product['price']
                    )
                    console.print("[green]Đã thêm vào giỏ thành công![/green]")
            else:
                console.print("[red]Số lượng phải > 0[/red]")
        except Exception as e:
            console.print(f"[red]Lỗi: {e}[/red]")
        
        console.input("Enter...")

# 3. HÀM MENU DANH SÁCH
def handle_view_products(current_user, product_repo, cart_repo):
    """
    Hàm quản lý hiển thị, tìm kiếm và lọc sản phẩm.
    """
    # 1. Trạng thái ban đầu: Lấy tất cả sản phẩm
    current_products = product_repo.get_all_product()
    list_title = "DANH SÁCH TẤT CẢ SẢN PHẨM"

    while True:
        clear() # Xóa màn hình mỗi khi lặp lại để giao diện sạch
        
        # --- PHẦN 1: HIỂN THỊ DANH SÁCH ---
        console.print(f"[bold cyan]--- {list_title} ---[/bold cyan]", justify="center")
        
        if not current_products:
            console.print("\n[red]Hiện tại không có sản phẩm nào trong danh sách này.[/red]", justify="center")
        else:
            # Tạo bảng hiển thị
            table = Table(show_header=True, header_style="bold magenta", border_style="dim")
            table.add_column("ID", style="cyan", width=6, justify="center")
            table.add_column("Tên sản phẩm", min_width=25)
            table.add_column("Giá", justify="right", style="green")
            table.add_column("Tồn kho", justify="right")
            
            # Danh sách ID hợp lệ để kiểm tra lựa chọn của user
            valid_ids = []
            
            for p in current_products:
                p_id = str(p['productID'])
                valid_ids.append(p_id)
                
                # Format giá tiền việt nam
                price_str = f"{float(p['price']):,.0f} đ"
                
                table.add_row(
                    p_id,
                    p['productName'],
                    price_str,
                    str(p['stock_quantity'])
                )
            console.print(table)

        # --- PHẦN 2: MENU ĐIỀU HƯỚNG ---
        console.print("\n[bold yellow]Thao tác:[/bold yellow]")
        console.print("[1] Nhập [bold green]ID sản phẩm[/bold green] để xem chi tiết & mua hàng")
        console.print("[2] Gõ [bold blue]'s'[/bold blue] để Tìm kiếm (Search)")
        console.print("[3] Gõ [bold blue]'c'[/bold blue] để Lọc theo Danh mục (Category)")
        console.print("[4] Gõ [bold blue]'a'[/bold blue] để Xem tất cả (All)")
        console.print("[0] Quay lại menu chính")
        
        choice = input("Lựa chọn của bạn: ").strip().lower()

        # --- PHẦN 3: XỬ LÝ LOGIC ---
        
        # >> 0. Quay lại
        if choice == '0':
            break

        # >> A. Xem tất cả (Reset)
        elif choice == 'a':
            current_products = product_repo.get_all_product()
            list_title = "DANH SÁCH TẤT CẢ SẢN PHẨM"

        # >> S. Tìm kiếm
        elif choice == 's':
            console.print("\n[bold cyan]TÌM KIẾM SẢN PHẨM[/bold cyan]")
            kw = input("Nhập tên hoặc mô tả sản phẩm: ").strip()
            if kw:
                results = product_repo.search_product(kw)
                current_products = results
                list_title = f"KẾT QUẢ TÌM KIẾM: '{kw}' ({len(results)} sp)"
            else:
                console.print("[red]Từ khóa không hợp lệ![/red]")
                input("Enter để tiếp tục...")

        # >> C. Lọc theo danh mục
        elif choice == 'c':
            # Lấy danh sách category để hiển thị cho user chọn
            categories = product_repo.get_all_categories()
            
            if categories:
                clear()
                console.print("[bold cyan]--- CHỌN DANH MỤC ---[/bold cyan]")
                cat_table = Table(show_header=True, header_style="bold blue")
                cat_table.add_column("ID", justify="center")
                cat_table.add_column("Tên Danh Mục")
                
                valid_cat_ids = []
                for cat in categories:
                    cat_id = str(cat['categoryID'])
                    valid_cat_ids.append(cat_id)
                    cat_table.add_row(cat_id, cat['categoryName'])
                
                console.print(cat_table)
                
                cat_choice = input("\nNhập ID danh mục (0 để hủy): ").strip()
                
                if cat_choice in valid_cat_ids:
                    # Gọi hàm lấy sản phẩm theo category ID
                    products_in_cat = product_repo.get_product_by_categoryID(cat_choice)
                    current_products = products_in_cat
                    
                    # Lấy tên danh mục để hiển thị tiêu đề cho đẹp
                    cat_name = next((c['categoryName'] for c in categories if str(c['categoryID']) == cat_choice), "Danh mục")
                    list_title = f"DANH MỤC: {cat_name}"
                
                elif cat_choice == '0':
                    pass # Không làm gì, quay lại vòng lặp chính
                else:
                    console.print("[red]ID danh mục không tồn tại![/red]")
                    input("Enter để quay lại...")
            else:
                console.print("[red]Hệ thống chưa có danh mục nào.[/red]")
                input("Enter để quay lại...")

        # >> Xử lý chọn ID sản phẩm để xem chi tiết
        # Logic: Kiểm tra xem choice (ID user nhập) có nằm trong danh sách valid_ids (đang hiển thị) không
        elif current_products and (choice in [str(p['productID']) for p in current_products]):
            # Lấy object sản phẩm tương ứng
            selected_p = next((p for p in current_products if str(p['productID']) == choice), None)
            
            if selected_p:
                # Gọi hàm xem chi tiết (Giả định bạn đã có hàm này hoặc sẽ viết)
                view_product_detail(current_user, selected_p, cart_repo)
                # Sau khi xem chi tiết xong, vòng lặp tiếp tục, giữ nguyên danh sách hiện tại
        
        else:
            console.print("[red]Lựa chọn không hợp lệ hoặc ID sản phẩm không có trong danh sách hiện tại.[/red]")
            input("Nhấn Enter để thử lại...")